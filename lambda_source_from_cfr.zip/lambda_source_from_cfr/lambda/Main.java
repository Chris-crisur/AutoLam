/*
 * Decompiled with CFR 0_101.
 */
package lambda;

import java.awt.Window;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import lambda.Context;
import lambda.Gui;
import lambda.Options;

public class Main {
    static /* synthetic */ Class class$lambda$Main;

    public static void main(String[] arrstring) {
        Window window = null;
        Options.parseOptions(arrstring);
        if (arrstring != null) {
            for (int i = 0; i < arrstring.length; ++i) {
                if (arrstring[i] == null) continue;
                try {
                    File file = new File(arrstring[i]);
                    if (!file.canRead()) {
                        System.err.println("cannot open file \"" + arrstring[i] + "\"");
                        System.err.println();
                        Main.printUsage();
                    }
                    if (window == null) {
                        window = new Gui();
                    }
                    window.getContext().importFile(file);
                    continue;
                }
                catch (IOException var3_4) {
                    System.err.println("error loading " + arrstring[i] + ":");
                    System.err.println("  " + var3_4);
                    System.err.println();
                    Main.printUsage();
                }
            }
        }
        if (window == null) {
            window = new Gui();
        }
        window.show();
    }

    private static void printUsage() {
        Class class_ = class$lambda$Main == null ? (Main.class$lambda$Main = Main.class$("lambda.Main")) : class$lambda$Main;
        System.err.println("usage: java " + class_.getName() + " [options] [filenames]");
        System.err.println();
        System.err.println("options:");
        Options.printOptions();
        System.exit(0);
    }

    static /* synthetic */ Class class$(String string) {
        try {
            return Class.forName(string);
        }
        catch (ClassNotFoundException var1_1) {
            throw new NoClassDefFoundError(var1_1.getMessage());
        }
    }
}

