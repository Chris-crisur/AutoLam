/*
 * Decompiled with CFR 0_101.
 */
package lambda;

class Symbol {
    static int last_code_assigned = 0;
    String data;
    int hash_code;

    Symbol(String string) {
        this.data = string.intern();
        this.hash_code = ++last_code_assigned;
    }

    public int hashCode() {
        return this.hash_code;
    }

    public boolean equals(Object object) {
        if (object instanceof String) {
            return this.data.equals(object);
        }
        return this == object;
    }

    public String toString() {
        return this.data;
    }

    public String getId() {
        return super.toString();
    }
}

