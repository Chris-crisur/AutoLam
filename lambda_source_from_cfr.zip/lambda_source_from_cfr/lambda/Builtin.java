/*
 * Decompiled with CFR 0_101.
 */
package lambda;

import java.util.HashMap;
import lambda.Expr;
import lambda.Symbol;

abstract class Builtin {
    static HashMap builtins = new HashMap<K, V>();

    Builtin() {
    }

    abstract int numArguments();

    abstract boolean canApply(Expr[] var1);

    abstract Expr apply(Expr[] var1);

    static Builtin get(String string, int n) {
        Builtin builtin = (Builtin)builtins.get(string);
        if (builtin != null && builtin.numArguments() == n) {
            return builtin;
        }
        return null;
    }

    static {
        builtins.put("+", new AddOperator());
        builtins.put("-", new SubOperator());
        builtins.put("*", new MultOperator());
        builtins.put("/", new DivOperator());
        builtins.put("=", new EqOperator());
        builtins.put("/=", new NeOperator());
        builtins.put("<", new LtOperator());
        builtins.put(">", new GtOperator());
        builtins.put("<=", new LeOperator());
        builtins.put(">=", new GeOperator());
        builtins.put("if", new IfOperator());
    }

    private static class IfOperator
    extends Builtin {
        private IfOperator() {
        }

        int numArguments() {
            return 3;
        }

        boolean canApply(Expr[] arrexpr) {
            String string;
            if (arrexpr[0] instanceof Expr.Ident && ((string = ((Expr.Ident)arrexpr[0]).sym.toString()).equals("true") || string.equals("false"))) {
                return true;
            }
            return false;
        }

        Expr apply(Expr[] arrexpr) {
            String string = ((Expr.Ident)arrexpr[0]).sym.toString();
            if (string.equals("true")) {
                return arrexpr[1];
            }
            return arrexpr[2];
        }
    }

    private static class GeOperator
    extends BinaryOperator {
        private GeOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n >= n2);
        }
    }

    private static class LeOperator
    extends BinaryOperator {
        private LeOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n <= n2);
        }
    }

    private static class GtOperator
    extends BinaryOperator {
        private GtOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n > n2);
        }
    }

    private static class LtOperator
    extends BinaryOperator {
        private LtOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n < n2);
        }
    }

    private static class NeOperator
    extends BinaryOperator {
        private NeOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n != n2);
        }
    }

    private static class EqOperator
    extends BinaryOperator {
        private EqOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n == n2);
        }
    }

    private static class DivOperator
    extends BinaryOperator {
        private DivOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + n / n2;
        }
    }

    private static class MultOperator
    extends BinaryOperator {
        private MultOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + n * n2;
        }
    }

    private static class SubOperator
    extends BinaryOperator {
        private SubOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n - n2);
        }
    }

    private static class AddOperator
    extends BinaryOperator {
        private AddOperator() {
            super();
        }

        String computeResult(int n, int n2) {
            return "" + (n + n2);
        }
    }

    private static abstract class BinaryOperator
    extends Builtin {
        private BinaryOperator() {
        }

        int numArguments() {
            return 2;
        }

        boolean canApply(Expr[] arrexpr) {
            if (arrexpr[0] instanceof Expr.Ident && arrexpr[1] instanceof Expr.Ident) {
                String string = ((Expr.Ident)arrexpr[0]).sym.toString();
                String string2 = ((Expr.Ident)arrexpr[1]).sym.toString();
                try {
                    Integer.parseInt(string);
                    Integer.parseInt(string2);
                    return true;
                }
                catch (NumberFormatException var4_4) {
                    // empty catch block
                }
            }
            return false;
        }

        Expr apply(Expr[] arrexpr) {
            String string = ((Expr.Ident)arrexpr[0]).sym.toString();
            String string2 = ((Expr.Ident)arrexpr[1]).sym.toString();
            String string3 = this.computeResult(Integer.parseInt(string), Integer.parseInt(string2));
            return new Expr.Ident(new Symbol(string3));
        }

        abstract String computeResult(int var1, int var2);
    }

}

