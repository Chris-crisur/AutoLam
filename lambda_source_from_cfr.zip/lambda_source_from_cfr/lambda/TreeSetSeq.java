/*
 * Decompiled with CFR 0_101.
 */
package lambda;

class TreeSetSeq {
    private Node root = null;
    int all_size = 0;

    public void add(Comparable comparable) {
        if (this.root == null) {
            this.root = new Node(null, comparable);
            this.all_size = 1;
            return;
        }
        ++this.all_size;
        Node node = this.root;
        do {
            if (comparable.compareTo(node.data) < 0) {
                ++node.left_size;
                if (node.left == null) {
                    node.left = new Node(node, comparable);
                    break;
                }
                node = node.left;
                continue;
            }
            if (node.right == null) {
                node.right = new Node(node, comparable);
                break;
            }
            node = node.right;
        } while (true);
    }

    public int getIndex(Comparable comparable) {
        if (this.root == null) {
            return -1;
        }
        int n = 0;
        Node node = this.root;
        while (node != null) {
            int n2 = comparable.compareTo(node.data);
            if (n2 < 0) {
                node = node.left;
                continue;
            }
            if (n2 == 0) {
                return n;
            }
            n+=node.left_size + 1;
            node = node.right;
        }
        return -1;
    }

    public int size() {
        return this.all_size;
    }

    public Object get(int n) {
        if (n < 0 || n >= this.size()) {
            return null;
        }
        Node node = this.root;
        int n2 = n;
        do {
            int n3;
            if (n2 < (n3 = node.left_size)) {
                node = node.left;
                continue;
            }
            if (n2 == n3) {
                return node.data;
            }
            n2-=n3 + 1;
            node = node.right;
        } while (true);
    }

    private static class Node {
        Comparable data;
        Node parent;
        Node left;
        Node right;
        int left_size;

        Node(Node node, Comparable comparable) {
            this.data = comparable;
            this.parent = node;
            this.left = null;
            this.right = null;
            this.left_size = 0;
        }
    }

}

